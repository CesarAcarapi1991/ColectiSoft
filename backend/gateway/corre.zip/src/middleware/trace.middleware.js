module.exports = (req, res, next) => {
  console.log(`[TRACE] ${req.method} ${req.url}`);
  next();
};