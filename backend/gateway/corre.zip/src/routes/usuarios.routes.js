require("dotenv").config();
const express = require('express');
const router = express.Router();
const axios = require('axios');

// const BASE_URL = 'http://localhost:3001';
const BASE_URL = process.env.USUARIOS_SERVICE;

router.post('/login', async (req, res) => {
    try {
        const response = await axios.post(`${BASE_URL}/usuarios/login`, req.body);
        res.json(response.data);
    } catch (error) {
        console.error(`Error en logina desde Gateway:  ${BASE_URL}`, error.message);
        res.status(error.response?.status || 500).json({ error: 'Error en login desde Gateway' });
    }
});

router.get('/', async (req, res) => {
    try {
        const response = await axios.get(`${BASE_URL}/usuarios`);
        res.json(response.data);
    } catch (error) {        
        console.error('Error al obtener usuarios desde Gateway:', error.message);
        res.status(error.response?.status || 500).json({ error: 'Error al obtener usuarios desde Gateway' });
    }
});
module.exports = router;