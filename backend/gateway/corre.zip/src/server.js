const express = require('express');
const cors = require('cors');

const trace = require('./middleware/trace.middleware');
const usuariosRoutes = require('./routes/usuarios.routes');

const app = express();

app.use(cors());
app.use(trace);
app.use(express.json());

app.use('/api/usuarios', usuariosRoutes);

const PORT = 3000;

app.listen(PORT, () => {
  console.log(`Gateway corriendo en http://localhost:${PORT}`);
});